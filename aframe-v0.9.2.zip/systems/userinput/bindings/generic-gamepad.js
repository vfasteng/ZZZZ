export const gamepadBindings = {};
