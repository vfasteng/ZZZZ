# Build an A-Frame Game!

This project template uses Don McCurdy's a-frame extras. 

Donmccurdy's extras:
https://github.com/donmccurdy/aframe-extras

His documentation is pretty good. Read it there. 



