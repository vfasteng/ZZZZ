# x1x

x1x.

Built with [A-Frame](https://aframe.io).

## Setup

```sh
npm install
npm run start
```
