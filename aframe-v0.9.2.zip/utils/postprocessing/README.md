These files
- EffectComposer.js
- MaskPass.js
- RenderPass.js
- ShaderPass.js
are copied from https://github.com/mrdoob/three.js/blob/dev/examples/js/postprocessing/EffectComposer.js

