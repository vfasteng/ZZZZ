These files
- CopyShader.js
- VignetteShader.js
were copied from https://github.com/mrdoob/three.js/blob/dev/examples/js/shaders/CopyShader.js

